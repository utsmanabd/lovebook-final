<main id="main">
  <!-- ======= About Section ======= -->
  <section id="about" class="about">
    <div class="container" data-aos="fade-up">

      <div class="section-header">
        <h2>Tentang Kami</h2>
        <p>Tentang <span>Lovebook</span></p>
      </div>

      <div class="row gy-4">
        <div class="col-lg-7 position-relative about-img" style="background-image: url(<?= base_url() ?>assets/img/about2.jpg) ;" data-aos="fade-up" data-aos-delay="150">
        </div>
        <div class="col-lg-5 d-flex align-items-end" data-aos="fade-up" data-aos-delay="300">
          <div class="content ps-0 ps-lg-5">
            <p style="text-align:justify">
              Lovebook merupakan wadah dimana seseorang bisa menjual dan membeli buku bekas original dalam bentuk aplikasi berbasis website. Lovebook
              merupakan inovasi baru karena sebelumnya belum ada wadah untuk melakukan transaksi jual-beli buku bekas original. Lovebook dapat memberikan
              manfaat terhadap lingkungan karena dapat mengurangi jumlah pohon yang harus ditebang hanya untuk menerbitkan buku yang sudah ada sebelumnya.
              Dengan adanya Lovebook ini juga dapat mengurangi limbah sampah kertas jika buku sudah tidak lagi dibaca. Selain itu, Lovebook juga dapat memudahkan
              seseorang untuk membaca buku yang ingin dibaca namun sudah tidak diterbitkan lagi.
            </p><br>
            <p><b>VISI</b></p>
            <p style="text-align:justify">Menjadi perusahaan layanan penjualan buku terbaik di Indonesia dengan menyediakan media yang aktif, inovatif, dan efisien bagi para pengguna. </p>
            <p style="text-align:justify"><b>MISI</b></p>
            <ul>
              <li><i class="bi bi-check2-all"></i> Menciptakan media yang responsif dan bertanggung jawab antara penjual dan pembeli buku. </li>
              <li><i class="bi bi-check2-all"></i> Menjadi perusahaan yang kreatif dan peka sehingga bisa beradaptasi dengan perkembangan pengetahuan dan teknologi. </li>
              <li><i class="bi bi-check2-all"></i> Memberikan komitmen dan rasa aman kepada seluruh pihak. </li>
              <li><i class="bi bi-check2-all"></i> Membangun rasa percaya antara mitra dengan pelanggan. </li>
            </ul>
          </div>
        </div>
      </div>

    </div>
  </section><!-- End About Section -->
</main><!-- End #main -->